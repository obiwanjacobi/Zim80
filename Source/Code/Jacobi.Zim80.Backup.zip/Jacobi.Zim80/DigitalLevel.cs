﻿namespace Jacobi.Zim80
{
    public enum DigitalLevel
    {
        Floating,
        Low,
        PosEdge,
        High,
        NegEdge,
    }
}