﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jacobi.Zim80.Components
{
    public class BusData24 : BusData
    {
        public BusData24()
            : base(24)
        { }
    }
}
