﻿namespace Jacobi.Zim80.Components.CpuZ80.Opcodes
{
    public enum Register16Table
    {
        BC,
        DE,
        HL,
        SP
    }
}
