﻿namespace Jacobi.Zim80.Components.CpuZ80.Opcodes
{
    public enum Register8Table
    {
        B,
        C,
        D,
        E,
        H,
        L,
        HL,
        A,
    }
}
