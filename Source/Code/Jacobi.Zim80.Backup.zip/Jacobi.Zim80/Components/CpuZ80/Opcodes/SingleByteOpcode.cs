﻿namespace Jacobi.Zim80.Components.CpuZ80.Opcodes
{
    internal class SingleByteOpcode : Opcode
    {
        public SingleByteOpcode(OpcodeDefinition opcodeDefinition)
        {
            Definition = opcodeDefinition;
            Text = Definition.Text;
        }

        public byte Value { get { return Definition.Value; } }
    }
}
