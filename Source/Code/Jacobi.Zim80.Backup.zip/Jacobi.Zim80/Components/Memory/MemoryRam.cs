﻿namespace Jacobi.Zim80.Components.Memory
{
    public class MemoryRam<AddressT, DataT> : MemoryRom<AddressT, DataT>
        where AddressT : BusData16, new()
        where DataT : BusData8, new()
    {
        public MemoryRam()
        {
            WriteEnable = new DigitalSignalConsumer();
        }

        public DigitalSignalConsumer WriteEnable { get; private set; }
    }
}
