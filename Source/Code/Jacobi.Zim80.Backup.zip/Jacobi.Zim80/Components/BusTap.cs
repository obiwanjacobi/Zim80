﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jacobi.Zim80.Components
{
    // taps of specific bus signals
    public class BusTap<T> : BusMasterSlave<T> 
        where T : BusData, new()
    {
        // mapping from source to target signal indexes
    }
}
