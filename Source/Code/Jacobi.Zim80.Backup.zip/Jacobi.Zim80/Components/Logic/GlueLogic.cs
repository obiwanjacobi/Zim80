﻿namespace Jacobi.Zim80.Components.Logic
{
    public class GlueLogic
    {
    }
}
