﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jacobi.Zim80.Components
{
    public class BusData20 : BusData
    {
        public BusData20()
            : base(20)
        { }
    }
}
