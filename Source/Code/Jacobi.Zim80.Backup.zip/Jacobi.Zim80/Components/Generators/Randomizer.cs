﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jacobi.Zim80.Components.Generators
{
    public class Randomizer
    {
        // adds random state to memory etc.
    }
}
